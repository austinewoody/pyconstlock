from setuptools import setup, find_packages

setup(
    name="pyconstlock",
    version="0.1.0",
    packages=find_packages(),
    description="A simple constant enforcement utility for Python",
    author="Austine Onwubiko",
    author_email="austineonwubiko@gmail.com",
    url="https://github.com/austinewoody/pyconstlock",
    classifiers=[
        "Programming Language :: Python :: 3",
    ],
    python_requires=">=3.6",
)